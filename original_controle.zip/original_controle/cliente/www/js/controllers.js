angular.module('starter.controllers', [])

.controller('DashCtrl', function($scope,$firebaseObject,$firebaseArray) {


  //var ref = firebase.database().ref();
  // download the data into a local object
  //$scope.data = $firebaseObject(ref);

//console.log($scope.data.e.confirmar);

  //var ref = Firebase(url: "https://hackathonbr-e7802.firebaseio.com/confirmar");

  //var ref = firebase.database().ref();
  // create a synchronized array
  // click on `index.html` above to see it used in the DOM!
  //$scope.messages = $firebaseArray(ref);
  //console.log($scope.messages);

  $scope.vlr_gorgeta = 200;

  var confirmar = firebase.database().ref('confirmar/');

  confirmar.on('value', function(snapshot) {

    $scope.confirmar = snapshot.val();
    console.log($scope.confirmar);
   $scope.$apply();

  });

  $scope.nao_enviar = function(){
     firebase.database().ref().set({
      confirmar: 0
    });
  }

  $scope.enviar = function(){

     firebase.database().ref().set({
      confirmar: 0
    });


  }





})

.controller('ChatsCtrl', function($scope, Chats) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  };
})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
})

.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
});
