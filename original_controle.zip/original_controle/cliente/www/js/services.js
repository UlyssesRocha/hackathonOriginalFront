angular.module('starter.services', [])

.factory('Chats', function($http) {
  // Might use a resource here that returns a JSON array

  


    /*
   $http.get('https://hackatonoriginalback.herokuapp.com/transaction-history',{
                headers: {
                    'Content-Type': 'application/json' , 
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'POST, GET',
                    'Access-Control-Allow-Headers':'X-Requested-With' 
                }
            }).success(function(data){
        $scope.things = data;
        console.log(data);
    });
    */





  // Some fake testing data
  var chats = [{
    id: 1,
    name: 'Maria',
    principal: 1,
    face: 'img/camila.png',
    conta:'111111-1'
  }, {
    id: 2,
    name: 'Monica',
    principal:0 ,
    face: 'img/maria.png',
    conta:'22222-2'
  }];

  return {
    all: function() {
      return chats;
    },
    remove: function(chat) {
      chats.splice(chats.indexOf(chat), 1);
    },
    get: function(chatId) {
      for (var i = 0; i < chats.length; i++) {
        if (chats[i].id === parseInt(chatId)) {
          return chats[i];
        }
      }
      return null;
    }
  };
});
